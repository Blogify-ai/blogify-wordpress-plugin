=== Plugin Name ===
Contributors: dmsbilas
Tags: version-1.0
Requires at least: 5.4
Tested up to: 6.0
Stable tag: 5.4
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.